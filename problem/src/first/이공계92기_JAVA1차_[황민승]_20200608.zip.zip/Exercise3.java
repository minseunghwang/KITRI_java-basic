package first;

class Exercise3 {
	public static void main(String[] args) {
		int num = -1;

		System.out.println((num >= 0) ? ((num == 0) ? 0 : "양수" ) : "음수");
	}
}