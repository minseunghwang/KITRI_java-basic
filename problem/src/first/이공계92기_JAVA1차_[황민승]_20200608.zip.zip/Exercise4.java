package first;

class Exercise4 {
	public static void main(String[] args) {
		int num = 456;

		System.out.println((int)Math.floor((double)num/100)*100);
	}
}