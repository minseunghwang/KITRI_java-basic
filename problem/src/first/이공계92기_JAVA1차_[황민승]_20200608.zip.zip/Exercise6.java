package first;

class Exercise6 {
	public static void main(String[] args) {
		int num = 24;

		System.out.println( 10-(num%10) );
	}
}