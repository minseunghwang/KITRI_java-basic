package first;

class Exercise5 {
	public static void main(String[] args) {
		int num = 777;

		System.out.println( num - num%10 + 1);
	}
}